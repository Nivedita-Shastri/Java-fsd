package pack2;
import pack1.*;

public class AccessSpecifiers4 {

	public static void main(String[] args) {
		
		ProtectedPublicAccessSpecifier obj = new ProtectedPublicAccessSpecifier(); 
        obj.display1();  
		
	}
}

