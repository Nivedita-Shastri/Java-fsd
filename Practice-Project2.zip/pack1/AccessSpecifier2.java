package pack1;

class accessspecifier 
{ 
 private void display1() 
  { 
      System.out.println("You are using private access specifier"); 
  } 
 
} 


public class AccessSpecifier2 {
	public static void main(String[] args) {
	 //private
  	System.out.println("Private Access Specifier");
  	accessspecifier  obj = new accessspecifier(); 
   //trying to access private method of another class 
   //obj.display();
}
}