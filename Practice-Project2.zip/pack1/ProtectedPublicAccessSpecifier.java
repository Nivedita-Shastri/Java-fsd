package pack1;


public class ProtectedPublicAccessSpecifier {

	protected void display() //protected method
  { 
      System.out.println("This is protected access specifier"); 
  } 
	public void display1() //public method
	{
		System.out.println("This is public access specifier");
	}
}