package pack18;

public class DemoClass {

String name;
String breed;
int age;
String color;

public DemoClass(String name, String breed, int age, String color) {
	
	this.name = name;
	this.breed = breed;
	this.age = age;
	this.color = color;
}

public String getName() {
	return name;
}



public String getBreed() {
	return breed;
}



public int getAge() {
	return age;
}



public String getColor() {
	return color;
}



@Override
public String toString() {
	return ("I have a dog. Her name is "+getName()+". She is a "+getBreed()+"."+"\nShe is only "+getAge()+" and her color is "+getColor()+".");
}
public static void main (String[] args) {
	DemoClass dog=new DemoClass("Mothi","Labrador",3,"White");
    System.out.println(dog.toString()); 
}
}
