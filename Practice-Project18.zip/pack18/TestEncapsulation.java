package pack18;

 class Encapsulate {
	
	private String Name;
	private int Id;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
}
	public class TestEncapsulation{
	public static void main(String[] args) {
	Encapsulate obj	=new Encapsulate();
	obj.setName("Nivedita");
	obj.setId(1002);
	System.out.println("My name is "+obj.getName());
	System.out.println("My Id is "+obj.getId());
	}
}
