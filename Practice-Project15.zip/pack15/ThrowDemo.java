package pack15;

public class ThrowDemo {
	public static void main(String[] args) {
		int a=20, b=0, n;
		try {
			if(b==0)throw((new ArithmeticException("Cannot divide by 0")));
			else{
				n=a/b;
				System.out.println("Result is"+n);
			}
		}
			catch(ArithmeticException e) {
				System.out.println("Error "+e.getMessage());
			}
		System.out.println("End of the program");
	}

}
