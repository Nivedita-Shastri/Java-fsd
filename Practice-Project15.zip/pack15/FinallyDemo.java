package pack15;

public class FinallyDemo {
	public static void main(String[] args) {
		int a=70,b=0,n=0;
		try {
			n=a/b;
		}
		catch(ArithmeticException e) {
			System.out.println("Error:"+e.getMessage());
		}
		finally {
			System.out.println("The Result is: "+n);
		}
	}

}
