package pack15;

public class ThrowsDemo {
	void Division()throws ArithmeticException{
		int a=40,b=0,n;
		n=a/b;
		System.out.println("Result"+n);
	}
public static void main(String[] args) {
	ThrowsDemo s=new ThrowsDemo();
	try {
	s.Division();
	}
	catch(ArithmeticException e) {
		System.out.println("Error"+e.getMessage());
	}System.out.println("END OF THE PROGRAM");
}
}
