package pack11;

public class MyThread extends Thread {
	public void run() {
		System.out.println("Concurrent Thread started running...");
	}

	public static void main(String[] args) {
		
		MyThread m=new MyThread();
		m.start();

	}

}
